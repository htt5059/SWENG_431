package com.company;

public class NameException extends Exception {
    public NameException(String err){
        super(err);
    }
}
